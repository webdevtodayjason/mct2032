#!/bin/bash
echo "Starting MCT2032 Admin Console..."
cd mct2032-admin
python3 -m pip install -r requirements.txt --quiet
python3 main.py
